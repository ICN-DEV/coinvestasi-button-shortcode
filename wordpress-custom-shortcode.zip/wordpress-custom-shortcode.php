<?php
/**
 * Plugin Name: Custom Banner Shortcode
 * Description: A custom plugin for embedding a banner with dynamic content.
 * Version: 1.6
 * Author: Farras Pratama
 */

function custom_banner_shortcode($atts) {
    // Shortcode attributes
    $atts = shortcode_atts(
        array(
            'banner_copy'   => 'Default Banner Copy',
            'button_url'    => 'https://coinvestasi.com/',
            'button_label'  => 'Default Button Label',
        ),
        $atts,
        'custom_banner'
    );

    // Sanitize and escape attribute values
    $banner_copy = esc_html($atts['banner_copy']);
    $button_url = esc_url($atts['button_url']);
    $button_label = esc_html($atts['button_label']);

    // Generate the HTML for the iframe with dynamic content
    $iframe_html = '<iframe id="customBannerIframe" src="https://icn-dev.github.io/coinvestasi-button-shortcode/banner.html" width="100%" height="auto" frameborder="0"></iframe>';

    // Generate the JavaScript to directly set parameters
    $script = '<script>
                  document.addEventListener("DOMContentLoaded", function() {
                      var iframe = document.getElementById("customBannerIframe");
                      if (iframe) {
                          iframe.contentWindow.postMessage({
                              bannerCopy: "' . $banner_copy . '",
                              buttonURL: "' . $button_url . '",
                              buttonLabel: "' . $button_label . '"
                          }, "https://icn-dev.github.io");
                      }
                  });
              </script>';

    return $iframe_html . $script;
}
add_shortcode('custom_banner', 'custom_banner_shortcode');
